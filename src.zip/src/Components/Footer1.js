import React, { Component } from 'react'
import './Footer1.css';

export default class Footer1 extends Component {
  render() {
    return (
      <div>
         <footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-links" Style="margin-left:30px;margin-right:30px">
        <h4>Useful Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="/">Home</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="/Aboutus">About us</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="/Contactus">Contact Us</a></li>
        </ul>
      </div>


      <div class="col-lg-3 col-md-6 footer-contact" Style="margin-left:30px;margin-right:30px">
        <h4>Contact Us</h4>
        <p>
          <strong>Phone:</strong> +1 5589 55488 55<br></br>
          <strong>Email:</strong> info@example.com<br></br>
        </p>

      </div>

      <div class="col-lg-3 col-md-6 footer-info" Style="margin-left:30px;margin-right:30px">
        <h3>About Us</h3>
        <p>Loan Management System</p><br />
        <p>Team 5</p>
      </div>

    </div>
  </div>
</div>

</footer> 
      </div>
    )
  }
}
