

const images = [{
    id: 1,
    src: "https://images.app.goo.gl/Tx9nFpcCndE2nHvM6",
    alt: "Image 1",
},
{
    id: 2,
    src: "https://images.app.goo.gl/6natPaUBFWVzhg6HA",
    alt: "Image 2 "
},
{
    id: 3,
    src: "https://images.app.goo.gl/6natPaUBFWVzhg6HA",
    alt: "Image 3"
}
];
export default images;