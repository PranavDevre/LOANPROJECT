import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import React from 'react'
import { SliderData } from "./SliderData";

  
const ImageSlider = ({images}) => {
  
  const settings = {
    infinite: true,
    dots: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    lazyLoad: true,
    autoplay: true,
  autoplaySpeed: 2000,
   
  };
  return (
    <>
    <div className="tag">
    </div>
      <div className="imgslider">
        <Slider {...settings}>
          {SliderData.map((item) => (
            <div>    
              <img src={item.image}  alt="Images" className="imageClass"/>
            </div>
          ))}
        </Slider>
      </div>
          </>
  )
}
export default ImageSlider;