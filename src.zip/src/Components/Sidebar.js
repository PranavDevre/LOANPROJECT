import React from 'react';
import { slide as Menu } from 'react-burger-menu';
import './Sidebar.css';

export default props => {
    return (
      <Menu>
        <a className="menu-item" href="/">
          Register
        </a>
        <br></br>

        <a className="menu-item" href="/AdminLogin">
          Login
        </a>
        <br></br>

        <a className="menu-item" href="/">
          Update
        </a>
        <br></br>

        <a className="menu-item" href="/">
          Delete
        </a>
        <br></br>
        <a className="menu-item" href="/">
          Change Password
        </a>
      </Menu>
    );
  };