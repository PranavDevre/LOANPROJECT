import React, { Component } from 'react'
import './Aboutus.css';
import Header from '../Components/Header';
import Footer1 from '../Components/Footer1';
export default class Aboutus extends Component {
    render() {
        return (
            <div>

                <div>
                    <Header />
                </div>
                <div id="login-box" Style="height:800px; width:800px" className='AboutusPage'>
                    <h1 Style="border-bottom: 2px solid  black;">LOAN MANAGEMENT SYSTEM</h1><br></br>
                    <p>The Loan Management System manages the process of originating loan orders, modifying/updating, 
                        and cancelling loan related information. The loan information accounts for the loan number, loan amount, 
                        loan term, borrower information, property information, status, loan management fees, origination date, origination account, 
                        lien information, legal documents, and loan history.</p>
                    <br></br>
                    <h3>Team Members</h3><br></br>
                    <div className='Name'><h4>Chithra Lekha</h4>
                    <p>Heaxware Employee (Trainee)</p>
                    <p>College : X.Y.Z. College, Shanti Lane, State, Country </p></div>
                    <div className='Name'><h4>Digambar Patil</h4>
                    <p>Heaxware Employee (Trainee)</p>
                    <p>College : X.Y.Z. College, Shanti Lane, State, Country </p></div>
                    <div className='Name'><h4>Divakar K R</h4>
                    <p>Heaxware Employee (Trainee)</p>
                    <p>College : X.Y.Z. College, Shanti Lane, State, Country </p></div>
                    <div className='Name'><h4>Gaurav Chavan</h4>
                    <p>Heaxware Employee (Trainee)</p>
                    <p>College : X.Y.Z. College, Shanti Lane, State, Country </p></div>
                    <div className='Name'><h4>Jayprakash V</h4>
                    <p>Heaxware Employee (Trainee)</p>
                    <p>College : X.Y.Z. College, Shanti Lane, State, Country </p></div>

                </div>
                <div>
                    <Footer1 />
                </div>
            </div>

        )
    }

}
