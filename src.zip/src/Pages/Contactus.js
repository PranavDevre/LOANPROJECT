import React, { Component } from 'react'
import './Contactus.css';
import Header from '../Components/Header';
import Footer1 from '../Components/Footer1';
export default class Contactus extends Component {
    render() {
        return (
            <div>

                <div>
                    <Header />
                </div>
                <div id="login-box" Style="height:800px; width:800px" className='AboutusPage'>
                    <h1 Style="margin-right:80px">Contact US</h1><br></br>
                    <div className='contactName' Style="padding=20px;margin=40px;"><h4>Chithra Lekha</h4>
                            <p>
                            <strong>Phone:</strong> +1 5589 55488 55<br></br>
                            <strong>Email:</strong> info@example.com<br></br>
                            </p>
                    </div>
                    <div className='contactName' ><h4>Digambar Patil</h4>
                            <p>
                                <strong>Phone:</strong> +1 5589 55488 55<br></br>
                                <strong>Email:</strong> info@example.com<br></br>
                            </p>
                    </div>
                    <div className='contactName' ><h4>Divakar K R</h4>
                            <p>
                                <strong>Phone:</strong> +1 5589 55488 55<br></br>
                                <strong>Email:</strong> info@example.com<br></br>
                            </p>
                    </div>
                    <div className='contactName'><h4>Gaurav Chavan</h4>
                            <p>
                                <strong>Phone:</strong> +1 5589 55488 55<br></br>
                                <strong>Email:</strong> info@example.com<br></br>
                            </p>
                    </div>
                    <div className='contactName' ><h4>Jayprakash V</h4>
                            <p>
                                <strong>Phone:</strong> +1 5589 55488 55<br></br>
                                <strong>Email:</strong> info@example.com<br></br>
                            </p>
                    </div>

                </div>
                <div>
                    <Footer1 />
                </div>
            </div>

        )
    }

}
