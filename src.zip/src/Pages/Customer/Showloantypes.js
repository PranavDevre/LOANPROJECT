import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios';
import './Showloantypes.css'
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';


export default class Showloantypes extends Component {
    constructor(props) {
        super(props)

        this.state = {
            loantypes: [],
            customerId: '',
            income:''
        }
    }

    displayloantypes() {
        let url = "http://localhost:11380/api/UserFunction";
        axios.get(url).then(Response => {
            this.setState({ loantypes: Response.data })
        }).catch(error => {
            console.warn(error);
            alert(error);
        })
    }

    submit()
    {
        window.location="/ApplyLoans";
    }

    submit1()
    {
        window.location="/UpdateUser";
    }

    submit2()
    {
        window.location="/DeleteUser";
    }

    submit3(){
        window.location="/CheckStatus";
    }

    componentDidMount() {
        this.displayloantypes();
    }

    render() {


        if (sessionStorage.getItem("customerId") == null) {
            window.location = '/';
        }
        else {
            this.state.customerId = sessionStorage.getItem('customerId');
            this.state.income = sessionStorage.getItem('income');
        }
        const { loantypes } = this.state;
        return (
            <>
            <div>
                <Header />
            </div>
            <div class = "buttons" Style="align:right;margin-left:800px">
                    
                    <button class="favorite styled" onClick={this.submit1}
                        type="button" Style="margin-left:400px">Update User
                    </button>

                    <button class="favorite styled" onClick={this.submit2}
                        type="button">Delete User
                    </button>

                </div>
                <div class={"LoanTypes"} className='LoanTypes'>


                    {/* <table border={1} cellPadding={2}>
    
              <tr> */}
                    <table class="flat-table" id='Table'>
                        <tbody>
                            <tr>



                                <th>Loan ID</th>
                                <th>Loan Type</th>
                                <th>Interest Rate</th>
                                <th>Max Tenure</th>





                            </tr>

                            {
                                loantypes.map(c =>
                                    <tr>



                                        <td>{c.loanId}</td>
                                        <td>{c.loanType}</td>
                                        <td>{c.interestRate}</td>
                                        <td>{c.maxTenure}</td>





                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                
                    {/* <Link to="/UpdateUser">Update</Link><br></br><br></br> */}

                    {/* <Link to="/DeleteUser">Delete</Link> */}
                    <button class="favorite styled" onClick={this.submit}
                        type="button">Apply Loans
                    </button>
                    
                    <button class="favorite styled" onClick={this.submit3}
                        type="button">Check Status
                    </button>

                </div>
                <div>
                    <Footer1 />
                </div>
            </>
        )
    }
}

{/* <div>Showloantypes
        <table>
            <tr>
                <td>
                    <th>LoanId</th>
                    <th>LoanType</th>
                    <th>Interestrate</th>
                    <th>Maxtenure</th>
                </td>
            </tr>
            {
                loantypes.map(c=>
                    <tr>
                <td>
                    <th>{c.loanId}</th>
                    <th>{c.loanType}</th>
                    <th>{c.interestRate}</th>
                    <th>{c.maxTenure}</th>
                </td>
            </tr>
                    )
            }
        </table>
        {/* <a href="/ApplyLoans">ApplyLoans</a> */}
        // <Link to="/ApplyLoans">ApplyLoans</Link>
