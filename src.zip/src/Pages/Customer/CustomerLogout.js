import React, { Component } from 'react'
import {Link} from 'react-router-dom';
import './CustomerLogout.css'

export default class CustomerLogout extends Component {
    constructor(props) {
        super(props)
      
        this.state = {
           
        }
        this.LogOut = this.LogOut.bind(this)
      }

    LogOut()
    {
        if(sessionStorage.getItem("customerId") != null)
        {
            sessionStorage.removeItem("customerId")
            window.location="/";
        }
    }


  render() {
    return (
      <div>
           <button onClick={this.LogOut} class="favorite styled" id='CustomerLogout'>LogOut</button>     
      </div>
    )
  }
}
