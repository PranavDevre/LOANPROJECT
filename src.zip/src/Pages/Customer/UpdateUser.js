import React, { Component } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
import CustomerLogout from './CustomerLogout';


export default class UpdateUser extends Component {
    constructor(props) {
        super(props)

        this.state = {
            customerId: '',
            name: '',
            password: '',
            confirmPassword: '',
            emailAddress: '',
            address: '',
            state: '',
            country: '',
            income: '',
            nameerror: '',
            passworderror: '',
            confirmPassworderror: '',
            emailAddresserror: '',
            addresserror: '',
            stateerror: '',
            countryerror: '',
            incomeerror:''
        }
        this.handleChange = this.handleChange.bind(this);
        this.Updateuser = this.Updateuser.bind(this);
    }
    Updateuser() {

        this.setState({
            nameerror:'',passworderror:'',confirmPassworderror:'',emailAddresserror: '',addresserror: '',stateerror: '',countryerror: '',
            incomeerror:''
        })

        if(this.Validate())
        {
            let customerId = this.state.customerId;
            let url = "http://localhost:11380/api/User/" + customerId;
            axios.put(url, {

            name: this.state.name,
            password: this.state.password,
            confirmPassword: this.state.confirmPassword,
            emailAddress: this.state.emailAddress,
            address: this.state.address,
            state: this.state.state,
            country: this.state.country,
            income: this.state.income

        }).then(response => {
            alert("Form has been submitted");
            alert("Customer Information Updated Successfully");
            window.location = "/UserLogin1";

        }).catch(error => {
            //alert("Please enter All the Details");
        });
            
        }
        

        

    }
    handleChange(changeObject) {
        this.setState(changeObject);

    }

    Validate()
    {
       if(!this.state.name.includes(" ") )
        {
            this.setState({nameerror:'Enter Your Full Name'});
        }
       else if(this.state.password.length<8)
        {
            this.setState({passworderror:'Password Length Should Be More Than 8 characters'}); 
        }
        else if(this.state.confirmPassword != this.state.password)
        {
            this.setState({confirmPassworderror:'Password  and confirm password should be same'}); 
        }
        else if(!this.state.emailAddress.includes("@"))
        {
            this.setState({emailAddresserror:'Please enter a valid email ID'}); 
        }
        else if(this.state.address.length<5)
        {
            this.setState({addresserror:'Please enter a valid address'}); 
        }
        else if(this.state.state.length<3)
        {
            this.setState({stateerror:'Please enter a valid state'}); 
        }
        else if(this.state.country.length<4)
        {
            this.setState({countryerror:'Please enter a valid country'}); 
        }
        else if(Number(this.state.income)<10000)
        {
            this.setState({incomeerror:'Income cannot be below 10,000 Rupees'}); 
        }
        else
        {
            return true;
        }
    }

    submit1()
    {
        window.location="/Showloantypes";
    }


    render() {

        if (sessionStorage.getItem("customerId") == null) {
            window.location = '/';
        }
        else {
            this.state.customerId = sessionStorage.getItem('customerId');
        }
        return (
            <>
                <div>
                    <Header />
                </div>
                <div class='Update'>
                    <div id="login-box" Style="height:fit-content;">
                            <h1 Style="padding-left: 0px;">User Details</h1>

                            <label className="labelName" Style="padding-left:100px">Name :</label>
                            <input type="text" Style="margin-left: 20px;" name="name" placeholder='Enter Full Name' onChange={(e) => this.handleChange({ name: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.nameerror}</p>
                            <label className="labelName" Style="padding-left:70px">Password :</label>
                            <input type="password" Style="margin-left: 20px;" name="password" placeholder='Enter Password' onChange={(e) => this.handleChange({ password: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.passworderror}</p>
                            <label className="labelName" Style="padding-left:0px">Confirm Password :</label>
                            <input type="password" Style="margin-left: 20px;" name="confirmPassword" placeholder='Enter Confirm Password' onChange={(e) => this.handleChange({ confirmPassword: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.confirmPassworderror}</p>
                            <label className="labelName" Style="padding-left:40px">Email Address :</label>
                            <input type="text" Style="margin-left: 20px;" name="emailAddress" placeholder='user@example.com' onChange={(e) => this.handleChange({ emailAddress: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.emailAddresserror}</p>
                            <label className="labelName" Style="padding-left:90px">Address :</label>
                            <input type="text" Style="margin-left: 20px;" name="address" placeholder='03, Shanti Nagar, Nashik' onChange={(e) => this.handleChange({ address: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.addresserror}</p>
                            <label className="labelName" Style="padding-left:120px">State :</label>
                            <input type="text" Style="margin-left: 20px;" name="state" placeholder='Assam, Goa' onChange={(e) => this.handleChange({ state: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.stateerror}</p>
                            <label className="labelName" Style="padding-left:100px">Country :</label>
                            <input type="text" Style="margin-left: 20px;" name="country" placeholder='India' onChange={(e) => this.handleChange({ country: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.countryerror}</p>
                            <label className="labelName" Style="padding-left:100px">Income :</label>
                            <input type="text" Style="margin-left: 20px;" name="income" placeholder='40000, 50000' onChange={(e) => this.handleChange({ income: e.target.value })}></input>
                            <p style={{color:"red"}}>{this.state.incomeerror}</p>


                            <button onClick={this.Updateuser} class="favorite styled "
                                type="button">
                                Update
                            </button><br></br><br></br>
                            <button class="favorite styled" onClick={this.submit1}
                        type="button">Show Loan Types
                    </button>
                                 
                    </div>
                    <CustomerLogout />
                </div>
                <div>
                    <Footer1 />
                </div>
            </>
        )
    }
}
