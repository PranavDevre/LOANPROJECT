import axios from 'axios';
import React, { Component } from 'react'
import './ApplyLoans.css'
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';

export default class ApplyLoans extends Component {
 
    // "loanNumber": 13,
    // "loanAmount": 5678,
    // "propertyAddress": "cdscds",
    // "dateOfApproval": "2022-11-03T16:47:24.7086887+05:30",
    // "loanStatus": "Applied",
    // "income": 4567,
    // "customerId": 3,
    // "adminId": 1,
    // "loanId": 1,
 
    constructor(props) {
   super(props)
 
   this.state = {
      loans:[],
      customerId:'',
      loanId:'',
      adminId:'',
      income:'',
      loanAmount:'',
      propertyAddress:'',
      loaniderror:'',
      loanAmounterror:'',
      propertyAddresserror:''
   }
   this.Applyloans=this.Applyloans.bind(this);
   this.handleChange=this.handleChange.bind(this);
 }

//  http://localhost:11380/api/UserFunction?userId=1&loanId=1&adminId=1&income=2344&LoanAmout=332&PropertyAddress=dsad
 Applyloans(){

    this.setState({
        loaniderror:'',loanAmounterror:'',propertyAddress:''
    })

    if(this.Validate()){

    let customerId = this.state.customerId;
    let loanId = this.state.loanId;
    let adminId = this.state.adminId;
    let income = this.state.income;
    let loanAmount = this.state.loanAmount;
    let propertyAddress = this.state.propertyAddress;
    let url="http://localhost:11380/api/UserFunction?userId="+customerId+"&"+"loanId="+loanId+"&"+"income="+income+"&"+"LoanAmout="+loanAmount+"&"+"PropertyAddress="+propertyAddress;    
    axios.post(url,{
        customerId:this.state.customerId,
        loanId:this.state.loanId,
        income:this.state.income,
        loanAmount:this.state.loanAmount,
        propertyAddress:this.state.propertyAddress

    }).then(response=>{alert("Loan Application has been sent for approval");
    window.location="/Showloantypes";
    })
  
    .catch(error=>{console.warn("error")});

 }
}

 Validate()
 {
    if(Number(this.state.loanId)<0 || this.state.loanId.length==0)
    {
        this.setState({loaniderror:"Plese enter valid Loan ID"});
    }
    else if(Number(this.state.loanAmount)<Number(this.state.income))
    {
        this.setState({loanAmounterror:"Plese enter valid Income"});
    }
    else if(this.state.propertyAddress.length<5)
    {
        this.setState({propertyAddresserror:'Please enter a valid property address'}); 
    }
    else
        {
            return true;
        }


 }

 submit1()
    {
        window.location="/Showloantypes";
    }

 handleChange(Object)
{
this.setState(Object);
}
 
 
    render() {
        if (sessionStorage.getItem("customerId") == null) {
            window.location = '/';
        }
        else {
            this.state.customerId = sessionStorage.getItem('customerId');
            this.state.income = sessionStorage.getItem('income');
        }


        const{loans}=this.state;
    return (
        <>
        <div>
            <Header />
        </div>

        <div>
        <div id="login-box">
        <div>
          <h1 Style="text-align:center;padding-right:30px; font-family:Verdana;">Apply For Loan</h1>

          
          {/* <input type="text" name="customerId" placeholder='customerId' onChange={(e) => this.handleChange({ customerId: e.target.value })}></input> */}
          {/* <input type="text" name="loanId" onChange={(e) => this.handleChange({ loanId: e.target.value })}></input> */}
          <label className="labelName">Loan ID :</label>
          <input Style="margin-left:100px;" type="text" name="loanId" placeholder='10000, 10001, 10002' onChange={(e) => this.handleChange({ loanId: e.target.value })}></input>
          <p style={{color:"red"}}>{this.state.loaniderror}</p>

          {/* <input type="text" name="adminId" onChange={(e) => this.handleChange({ adminId: e.target.value })}></input> */}
          {/* <input type="text" name="adminId" placeholder='adminId' onChange={(e) => this.handleChange({ adminId: e.target.value })}></input> */}
          {/* <input type="text" name="income" onChange={(e) => this.handleChange({ income: e.target.value })}></input> */}
          {/* <input type="text" name="income" placeholder='income' onChange={(e) => this.handleChange({ income: e.target.value })}></input> */}
          {/* <input type="text" name="loanAmount" onChange={(e) => this.handleChange({ loanAmount: e.target.value })}></input> */}
          <label className="labelName">Loan Amount ({'\u20B9'}) :</label>
          <input type="text" name="loanAmount" placeholder='1000000, 2000000' onChange={(e) => this.handleChange({ loanAmount: e.target.value })}></input>
          <p Style={{color:"red;"}}>{this.state.loanAmounterror}</p>

          <label className="labelName">Property Address :</label>
          {/* <input type="text" name="propertyAddress" onChange={(e) => this.handleChange({ propertyAddress: e.target.value })}></input> */}
          <input type="text" name="propertyAddress" placeholder='03, Sagar Apt, Larson Street...' onChange={(e) => this.handleChange({ propertyAddress: e.target.value })}></input>
          <p style={{color:"red"}}>{this.state.propertyAddresserror}</p>

          
         
         
          
          <button onClick={this.Applyloans} class="favorite styled"
        type="button">
    Apply
    </button><br></br><br></br>

    <button Style="align:left" class="favorite styled" onClick={this.submit1}
                        type="button">Show Loan Types
                    </button><br></br>
          
          
        </div>

        {/* <div class="right">
          <span class="loginwith">Sign in with<br />social network</span>

          <button class="social-signin facebook">Log in with facebook</button>
          <button class="social-signin twitter">Log in with Twitter</button>
          <button class="social-signin google">Log in with Google+</button>
        </div>
        <div class="or">OR</div> */}
        </div>
        
        

      </div>

      <div>
            <Footer1 />
        </div>

      </>
    )
  }
}

{/* <table>
            <tr>
                <td>
                    <label>customerId</label>
                    <input type="text" name="customerId" onChange={(e) => this.handleChange({ customerId: e.target.value })}></input>
                </td>
            </tr>

            <tr>
                <td>
                    <label>loanId</label>
                    <input type="text" name="loanId" onChange={(e) => this.handleChange({ loanId: e.target.value })}></input>
                </td>
                
            </tr>

            <tr>
                <td>
                    <label>adminId</label>
                    <input type="text" name="adminId" onChange={(e) => this.handleChange({ adminId: e.target.value })}></input>
                </td>
            </tr>
            <tr>
                <td>
                    <label>income</label>
                    <input type="text" name="income" onChange={(e) => this.handleChange({ income: e.target.value })}></input>
                </td>
            </tr>
            <tr>
                <td>
                    <label>loanAmount</label>
                    <input type="text" name="loanAmount" onChange={(e) => this.handleChange({ loanAmount: e.target.value })}></input>
                </td>
            </tr>
            <tr>
                <td>
                    <label>propertyAddress</label>
                    <input type="text" name="propertyAddress" onChange={(e) => this.handleChange({ propertyAddress: e.target.value })}></input>
                </td>
            </tr>
            <tr>
            <td>
               
               <button onClick={this.Applyloans} >Apply</button>
               
            </td>
            </tr>
        </table></> */}
