import axios from 'axios';
import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import './UserRegistration.css';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';



export default class UserRegistration extends Component {


  // "name": "string",
  // "password": "string",
  // "confirmPassword": "string",
  // "emailAddress": "user@example.com",
  // "address": "string",
  // "state": "string",
  // "country": "string",
  // "income": 0

  constructor(props) {
    super(props)

    this.state = {
      Users: [],
      customerId: '',
      name: '',
      password: '',
      confirmPassword: '',
      emailAddress: '',
      address: '',
      state: '',
      country: '',
      income: '',
      nameerror: '',
      passworderror: '',
      confirmPassworderror: '',
      emailAddresserror: '',
      addresserror: '',
      stateerror: '',
      countryerror: '',
      incomeerror:''
    }
    this.newuser = this.newuser.bind(this);
    this.handleChange = this.handleChange.bind(this);

  }

  //   DisplayUsers()
  // {
  //     let url="http://localhost:11380/api/User";
  //     fetch(url).then(response=>response.json()).then(result=>{
  // this.setState({Books:result})
  //     });
  //   }

  // componentDidMount()
  // {
  //     this.newuser();
  // }



  newuser() {

    this.setState({
      nameerror:'',passworderror:'',confirmPassworderror:'',emailAddresserror: '',addresserror: '',stateerror: '',countryerror: '',
      incomeerror:''
  })

  if(this.Validate())
  {
  
    let url = "http://localhost:11380/api/User";
    axios.post(url, {
      // customerId:this.state.customerId,
      name: this.state.name,
      password: this.state.password,
      confirmPassword: this.state.confirmPassword,
      emailAddress: this.state.emailAddress,
      address: this.state.address,
      state: this.state.state,
      country: this.state.country,
      income: this.state.income
    }).then(response => {
      alert("Record inserted");
      window.location = "/UserLogin1";

    }).catch(error => { alert(error);});


  }
}




  handleChange(changeObject) {
    this.setState(changeObject);
  }

  Validate()
  {
     if(!this.state.name.includes(" ") )
      {
          this.setState({nameerror:'Enter Your Full Name'});
      }
     else if(this.state.password.length<8)
      {
          this.setState({passworderror:'Password Length Should Be More Than 8 characters'}); 
      }
      else if(this.state.confirmPassword != this.state.password)
      {
          this.setState({confirmPassworderror:'Password  and confirm password should be same'}); 
      }
      else if(!this.state.emailAddress.includes("@"))
      {
          this.setState({emailAddresserror:'Please enter a valid email ID'}); 
      }
      else if(this.state.address.length<4)
      {
          this.setState({addresserror:'Please enter a valid address'}); 
      }
      else if(this.state.state.length<3)
      {
          this.setState({stateerror:'Please enter a valid state'}); 
      }
      else if(this.state.country.length<4)
      {
          this.setState({countryerror:'Please enter a valid country'}); 
      }
      else if(Number(this.state.income)<10000)
      {
          this.setState({incomeerror:'Income cannot be below 10,000 Rupees'}); 
      }
      else
      {
          return true;
      }
  }



  render() {

    const { Users } = this.state;
    return (
      <>
        <div>
          <Header />
        </div>

        <div id="login-box" Style="height:800px">
              <h1 Style={"text-align:center;padding-left:0px;font-family:Verdana;"}>Register Customer</h1>
           

            {/* <input type="text" name="username" placeholder="Username" /> */}
            <label className="labelName" Style="padding-left:100px">Name :</label>
            <input type="text" Style="margin-left:20px;" name="name" placeholder='Enter Full Name' onChange={(e) => this.handleChange({ name: e.target.value })} required></input>
            <p style={{color:"red"}}>{this.state.nameerror}</p>
            <label className="labelName" Style="padding-left:70px">Password :</label>
            <input type="password" Style="margin-left:20px;" name="password" placeholder='Enter Password' onChange={(e) => this.handleChange({ password: e.target.value })} ></input>
            <p style={{color:"red"}}>{this.state.passworderror}</p>
            <label className="labelName" Style="padding-left:0px">Confirm Password :</label>
            <input type="password" Style="margin-left:20px;" name="confirmPassword" placeholder='Enter Confirm password' onChange={(e) => this.handleChange({ confirmPassword: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.confirmPassworderror}</p>
            <label className="labelName" Style="padding-left:40px">Email Address :</label>
            <input type="text" Style="margin-left:20px;" name="emailaddress" placeholder='user@example.com' onChange={(e) => this.handleChange({ emailAddress: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.emailAddresserror}</p>
            <label className="labelName" Style="padding-left:90px">Address :</label>
            <input type="text" Style="margin-left:20px;" name="address" placeholder='03, Shanti Nagar, Nashik' onChange={(e) => this.handleChange({ address: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.addresserror}</p>
            <label className="labelName" Style="padding-left:120px">State :</label>
            <input type="text" Style="margin-left:20px;" name="state" placeholder='Assam, Goa' onChange={(e) => this.handleChange({ state: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.stateerror}</p>
            <label className="labelName" Style="padding-left:100px">Country :</label>
            <input type="text" Style="margin-left:20px;" name="country" placeholder='India' onChange={(e) => this.handleChange({ country: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.countryerror}</p>
            <label className="labelName" Style="padding-left:100px">Income :</label>
            <input type="text" Style="margin-left:20px;" name="income" placeholder='40000, 50000' onChange={(e) => this.handleChange({ income: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.incomeerror}</p>
            <button onClick={this.newuser} class="favorite styled"
              type="button">
              Register
            </button><br></br><br></br>


         

          
        </div>
        <div>
          <Footer1 />
        </div>

      </>
    )
  }
}


{/* <table>
        <tr>
          
        </tr>
        <tr>
          <td>
            <label>name</label>
            <input type="text" name="name" onChange={(e) => this.handleChange({ name: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>password</label>
            <input type="password" name="password" onChange={(e) => this.handleChange({ password: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>confirmPassword</label>
            <input type="password" name="confirmPassword" onChange={(e) => this.handleChange({ confirmPassword: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>emailAddress</label>
            <input type="text" name="emailaddress" onChange={(e) => this.handleChange({ emailAddress: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>address</label>
            <input type="text" name="address" onChange={(e) => this.handleChange({ address: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>state</label>
            <input type="text" name="state" onChange={(e) => this.handleChange({ state: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>country</label>
            <input type="text" name="country" onChange={(e) => this.handleChange({ country: e.target.value })}></input>
          </td>
        </tr>
        <tr>
          <td>
            <label>income</label>
            <input type="text" name="income" onChange={(e) => this.handleChange({ income: e.target.value })}></input>
          </td>
        </tr>
        <tr>
            <td>
               
               <button onClick={this.newuser} >Create</button>
               
            </td>
            </tr>
            </table>

        <table>
        

        
          
        </table></> */}
