import React, { Component } from 'react'
import axios from 'axios';
import './DeleteUser.css'
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';

export default class DeleteUser extends Component {
    constructor(props) {
        super(props)

        this.state = {
            customerId: ''
        }
        this.deleteuser = this.deleteuser.bind(this);
        this.handlechange = this.handlechange.bind(this);
    }
    deleteuser() {
        let id = this.state.customerId;
        let url = "http://localhost:11380/api/User/" + id;
        axios.delete(url).then(response => {
            alert("Customer Information has been Deleted");
            this.setState({ Users: response.data });
            window.location = "/UserLogin1";

        }).catch(error => {
            alert(error);
        })

    }

    submit1()
    {
        window.location="/Showloantypes";
    }

    
    handlechange(object) {
        this.setState(object);
    }
    render() {
        if (sessionStorage.getItem("customerId") == null) {
            window.location = '/';
        }
        else {
            this.state.customerId = sessionStorage.getItem('customerId');
        }
        return (
            <>
            <div>
                <Header />
            </div>
                <div class="Delete">
                    <h1 align="center"><b>Are You Sure You want To Delete Your Profile ? </b></h1> <br></br>

                    {/* <label>Enter the Customer Id</label>
        <input type="text" name="customerId" onChange={(e)=>this.handlechange({customerId:e.target.value})}></input> */}

                    <button onClick={this.deleteuser} class="submit_class"
                        type="button" Style="margin-bottom: 80px;">
                        Delete
                    </button><br></br><br></br>

                    <button onClick={this.submit1} class="submit_class"
                    type="button" Style="margin-bottom: 80px;">
                    Show Loan Types
                </button><br></br><br></br>


                </div>
            <div>
                <Footer1 />
            </div>
            </>
        )
    }
}
