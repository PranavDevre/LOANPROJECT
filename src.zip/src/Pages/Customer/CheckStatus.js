import React, { Component } from 'react'
import axios from 'axios';
import './ShowAllLoans.css';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
import CustomerLogout from './CustomerLogout';


export default class CheckStatus extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         Loans:[],
         customerId:'',
         loanNumber:'',
         loanType:'',
      }
      this.DisplayLoans=this.DisplayLoans.bind(this)
      this.handlechange=this.handlechange.bind(this)
    }

    DisplayLoans()
    {
        // http://localhost:11380/api/UserFunction/1
        let url = 'http://localhost:11380/api/UserFunction/'+this.state.customerId;
        axios.get(url).then(response=>{
            this.setState({Loans:response.data})
        }).catch(error=>{
            console.alert(error);
        })
    }

    componentDidMount()
    {
        this.DisplayLoans();
    }
    handlechange(object)
    {
        this.setState(object);
    }

    submit()
    {
        window.location="/customerLoanStatus";
    }

    submit1()
    {
        window.location="/Showloantypes";
    }

    submit2()
    {
        alert("In Cust Logout")
        window.location="/CustomerLogout";
    }


    
  render() {
     let {loanType} = ''
    // if(this.state.adminId=='1'){
    //     {loanType = 'Home Loan'};
    // }
    // else if(this.state.adminId=='2'){
    //     {loanType = 'Home Improvement'};
    // }
    // else if(this.state.adminId=='3'){
    //     {loanType = 'Home Expansion'};
    // }
    // else{
    //     {loanType = 'Purchase Land'};
    // }
   

    if(sessionStorage.getItem("customerId") == null)
    {
        window.location='/';
    }
    else{
        this.state.customerId = sessionStorage.getItem('customerId');
    }

  
    const {Loans} = this.state;

   

    return (
        <>  
        <div class='loanHeader'>
            <Header />
        </div>   
        <div class="loanTable" align={"center"}>
            {/* <h1 align={"left"}>Loan Type : {loanType}</h1> */}
            <table class="flat-table">
                <tbody>
                <tr>
                    <th>Loan Number</th>
                    <th>Loan Amount</th>
                    <th>Property Address</th>
                    <th>Date of Approval</th>
                    <th>Income</th>
                    <th>Loan Status</th>
                    
                    <th>Loan ID</th>
                    
                </tr>
                {Loans.map(item => <tr>
                    <td>{item.loanNumber}</td>
                    <td>{item.loanAmount}</td>
                    <td>{item.propertyAddress}</td>
                    <td>{(item.dateOfApproval)}</td>
                    <td>{item.income}</td>
                    <td>{item.loanStatus}</td>
                    
                    <td>{item.loanId}</td>
                    
                </tr>
                )}
                </tbody>
            </table>
            <button Style="align:left" class="favorite styled" onClick={this.submit1}
                        type="button">Show Loan Types
                    </button>
                    <CustomerLogout></CustomerLogout> 
                    {/* <button Style="align:left" class="favorite styled" onClick={this.submit2}
                        type="button">Logout
                    </button> */}
            <div class="Links">
            {/* <button onClick={this.submit} class="btn btn-outline-warning" type="button" id='UpdateStatus'>Update Loan Status</button>*/}
            
            
            </div>
      </div>
      <div>
        <Footer1 />
      </div>
      </>
    )
  }
}
