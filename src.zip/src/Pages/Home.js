import React, { Component } from 'react'
import Header from '../Components/Header'
import Footer1 from '../Components/Footer1'
import images from '../Components/images';
//import ImageSlider from '../Components/imageSlider';
import './Home.css'

export default class Home extends Component {
  render() {
    return (
        <div >
      <div>
        <Header />
      </div >
      <div className='HomePage'>
        {/* <ImageSlider images={images}/> */}
      </div>
      
      <div>
        <Footer1 />
      </div>
      </div>
    )
  }
}
