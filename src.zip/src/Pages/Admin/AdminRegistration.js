import axios from 'axios'
import React, { Component } from 'react'
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
import './AdminRegistration.css';

export default class AdminRegistration extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        adminId:'',
        name:'',
        password:'',
        confirmPassword:'',
        emailAddress:''

      }
      this.handleChange=this.handleChange.bind(this);
      this.Registration=this.Registration.bind(this);
    }

    
    
    Registration()
    {
      this.setState({
        nameerror:'',passworderror:'',confirmPassworderror:'',emailAddresserror: ''
    })
    if(this.Validate())
        {

        let url='http://localhost:11380/api/Admin'
        axios.post(url,{
          name:this.state.name,
          password:this.state.password,
          confirmPassword:this.state.confirmPassword,
          emailAddress:this.state.emailAddress,
        }).then(Response=>
          {
            alert("Registration Succesful")
          }).catch(error=>
            {
              alert("error")
            });
        window.location = "/AdminRegisterLoan";
        }
    }
  

    handleChange(object)
    {
      this.setState(object)

    }

    Validate()
    {
       if(!this.state.name.includes(" ") )
        {
            this.setState({nameerror:'Enter Your Full Name'});
        }
       else if(this.state.password.length<8)
        {
            this.setState({passworderror:'Password Length Should Be More Than 8 characters'}); 
        }
        else if(this.state.confirmPassword != this.state.password)
        {
            this.setState({confirmPassworderror:'Password  and confirm password should be same'}); 
        }
        else if(!this.state.emailAddress.includes("@"))
        {
            this.setState({emailAddresserror:'Please enter a valid email ID'}); 
        }
       
        else
        {
            return true;
        }
    }



  render() {
    return (

        <>
        <div>
          <Header />
        </div>

        <div id="login-box">
              <h1 Style={"text-align:center;padding-left:0px;font-family:Verdana;"}>Admin Registration</h1>  

            {/* <input type="text" name="username" placeholder="Username" /> */}
            <label className="labelName" Style="padding-left:100px">Name :</label>
            <input type="text" Style="margin-left:20px;" name="name" placeholder='Full Name' onChange={(e) => this.handleChange({ name: e.target.value })} ></input>
            <p style={{color:"red"}}>{this.state.nameerror}</p>
            <label className="labelName" Style="padding-left:70px">Password :</label>
            <input type="password" Style="margin-left:20px;" name="password" placeholder='Enter Password' onChange={(e) => this.handleChange({ password: e.target.value })} ></input>
            <p style={{color:"red"}}>{this.state.passworderror}</p>
            <label className="labelName">Confirm Password :</label>
            <input type="password" Style="margin-left:20px;" name="confirmPassword" placeholder='Enter Confirm Password' onChange={(e) => this.handleChange({ confirmPassword: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.confirmPassworderror}</p>
            <label className="labelName" Style="padding-left:40px">Email Address :</label>
            <input type="text" Style="margin-left:20px;" name="emailaddress" placeholder='user@example.com' onChange={(e) => this.handleChange({ emailAddress: e.target.value })}></input>
            <p style={{color:"red"}}>{this.state.emailAddresserror}</p>
            <button onClick={this.Registration} class="favorite styled"
              type="button">
              Register
            </button><br></br><br></br>
       
        </div>
        <div>
          <Footer1 />
        </div>

      </>
    )
  }
}












//       <div>AdminRegistration
//  <table border={1} align="center">
//         {/* <tr>
//             <td>
//                 <label>adminId</label>
//                 <input type="text" name="adminId" onChange={(e)=>this.handleChange({adminId:e.target.value})}></input>
//             </td>
//             </tr> */}
//             <tr>
//             <td>
//                 <label>name</label>
//                 <input type="text" name="name" onChange={(e)=>this.handleChange({name:e.target.value})}></input>
//             </td>
//             </tr>
//             <tr>
//             <td>
//                 <label>password</label>
//                 <input type="text" name="password" onChange={(e)=>this.handleChange({password:e.target.value})}></input>
//             </td>
//             </tr>

//             <tr>
//             <td>
//                 <label>confirmPassword</label>
//                 <input type="text" name="confirmPassword" onChange={(e)=>this.handleChange({confirmPassword:e.target.value})}></input>
//             </td>
//             </tr>

//             <tr>
//             <td>
//                 <label>emailAddress</label>
//                 <input type="text" name="emailAddress" onChange={(e)=>this.handleChange({emailAddress:e.target.value})}></input>
//             </td>
//             </tr>
//             <tr>
//             <td>
               
//                <button onClick={this.Registration} >Registration</button>
//             </td>
//             </tr>
      

//         </table>

       
//       </div>
//     )
//   }
// }
