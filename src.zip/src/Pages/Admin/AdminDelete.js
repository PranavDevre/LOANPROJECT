import React, { Component } from 'react'
import axios from 'axios';
import AdminLogout from './AdminLogout';
import './AdminDelete.css'
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';

export default class AdminDelete extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        adminId:'',
        loanId:''
      }
      this.AdminDelete=this.AdminDelete.bind(this);
      this.handlechange=this.handlechange.bind(this);
    }
    AdminDelete()
    {
        alert(this.state.adminId)
        alert(this.state.loanId)
        let url="http://localhost:11380/api/AdminFunction/DeleteLoan?id="+this.state.loanId;
        axios.delete(url).then(resp=>{
        // alert(resp.data);
            this.setState({Loans:resp.data});
            //alert("Admin and Loan Record has been Deleted");
            //window.location = "/AdminLogin";
        }).catch(error=>{
            console.warn(error);
        })

        let adminId=this.state.adminId;
        url="http://localhost:11380/api/Admin/"+adminId;
        axios.delete(url).then(resp=>{
        // alert(resp.data);
            this.setState({Admins:resp.data});
            alert("Admin Record has been Deleted");
            window.location = "/AdminLogin";
        }).catch(error=>{
            console.warn(error);
        })

    }
    handlechange(object)
    {
        this.setState(object);
    }

    submit1()
    {
        window.location="/ShowAllLoans";
    }


  render() {
    const{loanId} = ''
    if(sessionStorage.getItem("adminId") == null)
    {
        window.location='/';
    }
    else{
        this.state.adminId = sessionStorage.getItem('adminId');
        this.state.loanId = sessionStorage.getItem('adminId');
    }
    return (
        <>
        <div>
            <Header />
        </div>
            <div class="Delete">
                <h1 align="center"><b>Are You Sure You want To Delete Your Profile ? </b></h1> <br></br>

                <button onClick={this.AdminDelete} class="submit_class"
                    type="button" Style="margin-bottom: 80px;">
                    Delete
                </button><br></br><br></br>

                <button onClick={this.submit1} class="submit_class"
                    type="button" Style="margin-bottom: 80px;">
                    Show Applied Loans
                </button><br></br><br></br>


            </div>
        <div>
            <AdminLogout></AdminLogout>
            <Footer1 />
        </div>
        </>
    )
}
}



//       <div>AdminDelete
//         <label>Enter the Admin Id</label>
//         <input type="text" name="adminId" onChange={(e)=>this.handlechange({adminId:e.target.value})}></input>
//     <button onClick={this.AdminDelete}>Delete</button>
//     <AdminLogout></AdminLogout>
//       </div>
//     )
//   }
// }
