import React, { Component } from 'react'
import axios from 'axios'
import "./AdminLogin.css";
import { Link } from 'react-router-dom';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
export default class AdminLogin extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        adminId:'',
        password:'',
        adminIderror:'',
        passworderror:''
      }
      this.submit=this.submit.bind(this);
      this.handlechange=this.handlechange.bind(this);
    }
    submit()
    {

      this.setState({
          adminIderror:'',passworderror:''
      })

      if(this.Validate())
      {

        let adminId=this.state.adminId;
        let password=this.state.password;
        let url="http://localhost:11380/api/Admin/"+adminId+","+password;
        axios.get(url,{
            adminId:this.state.adminId,
            password:this.state.password

        }).then(response=>{
            if(response.data.adminId!=null)
            {
            alert("Login Successful");
            sessionStorage.setItem("adminId",response.data.adminId);
            window.location="/ShowAllLoans";

            }
            else
            {
                alert("Invalid ID/Password");
            }

        }).catch(error=>{
            //alert("Please enter All the Details");
        });
        }


    }
    handlechange(object)
    {
        this.setState(object);

    }

    Validate()
    {
      if(Number(this.state.adminId)<0 || this.state.adminId.length==0)
      {
        this.setState({adminIderror:"Please enter valid Admin ID"});
      }
      else if(this.state.password.length<8)
      {
        this.setState({passworderror:"Password Length Should be more than 8 characters"});
      }
      else
        {
            return true;
        }
    }

  render() {
    return (

      <>
      <div>
        <Header></Header>
          
      </div>
      <div id='MainContent'>
      <div class="row">
          <div class="colm-logo" Style="height:400px;width:400px;padding-top:20px;padding-bottom:20px;">
            <img src='AdminImage.jpg' alt='Admin Image' className='AdminImage'></img>
          </div>
          <div class="colm-form">
              <div class="form-container" Style="width: 400px;height: 400px;margin-top: 50px;">
              <input type="text" name="adminId" placeholder='Admin Id' onChange={(e) => this.handlechange({ adminId: e.target.value })}></input>
              <p style={{color:"red"}}>{this.state.adminIderror}</p>
              <input type="password" name="password" placeholder='Password' onChange={(e) => this.handlechange({ password: e.target.value })}></input>
              <p style={{color:"red"}}>{this.state.passworderror}</p>
              <button onClick={this.submit} class="btn-login" type="button" Style="margin-top:20px">Login </button>
                  <a href="/AdminForgotPassword" Style="margin-top:20px">Forgot password</a>
                  <a class="btn btn-outline-success" href="/AdminRegistration" role="button">Register Admin</a>
              </div>
          </div>
      </div>
      </div>
      <div>
        <Footer1></Footer1>
          
      </div>
  </>

      // <><div>Admin Login</div><html lang="en">
      //   <head>
      //     <meta charset="UTF-8"></meta>
      //     <meta http-equiv="X-UA-Compatible" content="IE=edge"></meta>
      //     <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
      //     <title>Facebook-Login or Sign up</title>
      //     <link rel="stylesheet" href="style2.css"></link>
      //   </head>
      //   <body>
      //     <main>
      //       <div class="row">
      //         <div class="colm-logo">
      //           <h2></h2>
      //         </div>
      //         <div class="colm-form">
      //           <div class="form-container">

      //             <input type="text" name="adminId" placeholder='Admin Id' onChange={(e) => this.handlechange({ adminId: e.target.value })}></input>

      //             <input type="password" name="password" placeholder='Password' onChange={(e) => this.handlechange({ password: e.target.value })}></input>
                 
      //             <button onClick={this.submit} class="favorite styled" type="button">Login </button>
      //             <a href="/AdminChangePassword">Forgotten password?</a>
                 


      //             <button class="btn-new">
      //               <Link to="/AdminRegistration">Create new Account</Link>
      //             </button>
      //           </div>
               
      //         </div>
      //       </div>
      //     </main>
      //     <footer></footer>
          

      //   </body>
      // </html></>
              )
         }
    }


//     import React, { Component } from 'react'
// import Header from '../Components/Header';
// import Footer from '../Components/Footer';

// export default class AdminLogin extends Component {
//     render() {
//         return (