import React, { Component } from 'react'
import {Link} from 'react-router-dom';


export default class AdminLogout extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         
      }
      this.LogOut = this.LogOut.bind(this)
    }

    LogOut()
    {
        if(sessionStorage.getItem("adminId") != null)
        {
            sessionStorage.removeItem("adminId")
            window.location="/AdminLogin";
        }
    }
    
  render() {
    return (
      <div>
        
        <button onClick={this.LogOut} class="btn btn-outline-danger" id='Logout'>LogOut</button>
      </div>
    )
  }
}