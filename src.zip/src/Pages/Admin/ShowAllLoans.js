import React, { Component } from 'react'
import axios from 'axios';
import './ShowAllLoans.css';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
import Sidebar from '../../Components/Sidebar';
import AdminLogout from './AdminLogout';
import {BrowserRouter, Routes, Route, Router,  Link} from 'react-router-dom';

export default class ShowAllLoans extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         Loans:[],
         adminId:'',
         loanNumber:'',
         loanType:'',
         getLoanNo:''
      }
      this.DisplayLoans=this.DisplayLoans.bind(this)
      this.handlechange=this.handlechange.bind(this)
    }

    DisplayLoans()
    {
        let url = 'http://localhost:11380/api/AdminFunction?adminId='+this.state.adminId;
        axios.get(url).then(response=>{
            this.setState({Loans:response.data});       
        }).catch(error=>{
            console.alert(error);
        })
    }

    componentDidMount()
    {
        this.DisplayLoans();
    }
    handlechange(object)
    {
        this.setState(object);
    }

    submit()
    {
        //sessionStorage.setItem("loanNumber",this.state.getLoanNo);
        
        window.location="/AdminLoanStatus";
    }
    
    submit1()
    {
        window.location="/AdminEdit";
    }

    submit2()
    {
        window.location="/AdminDelete";
    }


  render() {

    
   

    if(sessionStorage.getItem("adminId") == null)
    {
        window.location='/';
    }
    else{
        this.state.adminId = sessionStorage.getItem('adminId');
    }

  
    const {Loans} = this.state;
    {Loans.map(item => item.loanNumber)}
    return (
        <>  
        <div class='loanHeader'>
            <Header />
        </div>   
        <div class="loanTable" align={"center"} id="loanTableId">
        {/* <Sidebar pageWrapId={'page-wrap'} outerContainerId={'loanTableId'} /> */}
        <div id="page-wrap">
            <h1 align={"left"} Style={"padding-left:110px;display:inline-block;"}>Admin ID : {this.state.adminId}</h1>

            <table class="flat-table">
                <tbody>
                <tr>
                    <th>Loan Number</th>
                    <th>Customer ID</th>
                    <th>Loan Amount</th>
                    <th>Property Address</th>
                    <th>Date of Approval</th>
                    <th>Income</th>
                    <th>Loan Status</th>
                    <th>Select (Any One)</th>
                    
                </tr>
                {Loans.map(item => <tr>
                    <td>{item.loanNumber}</td>
                    <td>{item.customerId}</td>
                    <td>{item.loanAmount}</td>
                    <td>{item.propertyAddress}</td>
                    <td>{item.dateOfApproval}</td>
                    <td>{item.income}</td>
                    <td>{item.loanStatus}</td>
                    <td><button class="btn btn-outline-warning" type="button" id='UpdateStatus'><Link to={"/AdminLoanStatus/?id="+item.loanNumber}>Update</Link></button></td>
                </tr>
                )}
                </tbody>
            </table>

                    <button class="favorite styled" onClick={this.submit1}
                        type="button">Update Admin
                    </button>

                    <button class="favorite styled" onClick={this.submit2}
                        type="button">Delete Admin
                    </button>
                    
                    <div Style="display:inline-block;padding-left:900px">
                        <AdminLogout />
                    </div>
                
        </div>
      </div>
      <div>
        <Footer1 />
      </div>
      </>
    )
  }
}