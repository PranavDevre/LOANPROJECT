import React, { Component } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';

export default class AdminRegisterLoan extends Component {
    constructor(props) {
        super(props)
        this.state = {
            Loans: [],
            loanType: "",
            interestRate: '',
            maxTenure: '',
            loantyeerror: '',
            roierror: '',
            tenureerror: ''
        }
        this.loan = this.loan.bind(this);
        this.handleChange = this.handleChange.bind(this);

    }

    loan() {

        this.setState({
            loantyeerror: '', roierror: '', tenureerror: ''
        })
        if (this.Validate()) {

            let url = "http://localhost:11380/api/AdminFunction/RegisterLoan";
            axios.post(url, {
                loanType: this.state.loanType,
                interestRate: this.state.interestRate,
                maxTenure: this.state.maxTenure
            }).then(response => {
                alert("Loan has been successfully registered");
                window.location = "/AdminLogin";

            }).catch(error => { alert(error); });
        }
    }
    handleChange(changeObject) {
        this.setState(changeObject);
    }

    Validate() {
        if (this.state.loanType.includes("0123456789!@#$%^&*()_+{}:'<>?/") || this.state.loanType.length == 0) {
            this.setState({ loantyeerror: "Please enter valid loan type (No numbers or special characters ) " });
        }
        else if (this.state.interestRate < 5) {
            this.setState({ roierror: 'Rate of Interest can not be less than 5%' });
        }
        else if (this.state.maxTenure > 50) {
            this.setState({ tenureerror: 'Minimum Tenure is 20 months and Maximum Tenure is 48 months' });
        }
        else {
            return true;
        }
    }




    render() {
        const { Loans } = this.state;
        return (
            <>  
               <div>
                <Header />
                </div>   
                <div id="login-box">
                    <h1 Style={"text-align:center;padding-left:0px;font-family:Verdana;"}>Register Loan</h1>

                        <label className="labelName" Style="padding-left:120px">Loan Type :</label>
                        <input type="text" Style="margin-left:20px;" name="loanType" placeholder='Purchase Land, Home Loan' onChange={(e) => this.handleChange({ loanType: e.target.value })} required></input>
                        <p style={{ color: "red" }}>{this.state.loantyeerror}</p>
                        <label className="labelName" Style="padding-left:70px">Interest Rate(%) :</label>
                        <input type="text" Style="margin-left:20px;" name="interestRate" placeholder='10, 12' onChange={(e) => this.handleChange({ interestRate: e.target.value })} ></input>
                        <p style={{ color: "red" }}>{this.state.roierror}</p>
                        <label className="labelName" Style="padding-left:30px">Max Tenure(months) :</label>
                        <input type="text" Style="margin-left:20px;" name="maxTenure" placeholder='24, 48' onChange={(e) => this.handleChange({ maxTenure: e.target.value })}></input>
                        <p style={{ color: "red" }}>{this.state.tenureerror}</p>

                        <button onClick={this.loan} class="favorite styled" type="button"> Create </button><br></br><br></br>
                    
                </div>
                <div>
                    <Footer1 />
                </div>
            </>

        )
    }

}
