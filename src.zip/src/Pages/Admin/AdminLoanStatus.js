import React, { Component } from 'react'
import axios from 'axios'
import AdminLogout from './AdminLogout'
import Header from '../../Components/Header'
import Footer1 from '../../Components/Footer1'

export default class AdminLoanStatus extends Component {
    constructor(props) {
        super(props)

        this.state = {
            Loans: [],
            adminId: '',
            loanNumber: '',
            loanStatus: '',
            updateerror:''

        }
        this.AdminLoanStatus = this.AdminLoanStatus.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    AdminLoanStatus() {

        this.setState({
            updateerror:''
        })

        if(this.Validate()){

        let adminId = this.state.adminId;
        let loanNumber = this.state.loanNumber;
        let loanStatus = this.state.loanStatus;
        let url = "http://localhost:11380/api/AdminFunction?adminId=" + adminId + "&loanNumber=" + loanNumber + "&status=" + loanStatus;
        axios.post(url, {
            loanNumber: this.state.loanNumber,
            loanStatus: this.state.loanStatus,

        }).then(response => {
            alert("Loan Status Updated");
            window.location="/ShowAllLoans";

        }).catch(error => {
            alert("This Admin ID does not have permission");
        });

    }
    
}

    Validate()
    {
        if(this.state.loanStatus.length == 0 || (this.state.loanStatus.includes(" ")))
        {
            this.setState({updateerror:"Please enter valid status"})
        }
        else{
            return true;
        }
    }

    submit1()
    {
        window.location="/ShowAllLoans";
    }


    handleChange(object) {
        this.setState(object);

    }
    render() {
        const UrlParam = new URLSearchParams(window.location.search);

        if (sessionStorage.getItem("adminId") == null) {
            window.location = '/';
        }
        else {
            this.state.adminId = sessionStorage.getItem('adminId');
            this.state.loanNumber = UrlParam.get('id');
        }

        return (
            <>
                <div>
                    <Header />
                </div>
                <div className='UpdateStatus'>

                    <div class="d-flex justify-content-center align-items-center mt-5">


                        <div class="card" Style={"margin-top:0px; margin-bottom:3rem!important"}>
                            <h2 align={"center"} Style={"padding-top:20px;font-family: font-family:Verdana, Geneva, Tahoma, sans-serif;margin-bottom:0px "}>Update Status</h2>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">

                                    <div class="form px-4 pt-5" Style={"width:400px"}>
                                        {/* <input type="text" class="form-control" placeholder="Enter Loan Number " Style={"margin-bottom:20px;margin-left: 80px;"} name="loanNumber" onChange={(e) => this.handleChange({ loanNumber: e.target.value })}></input> */}
                                        {/* <input type="text" name="" class="form-control" placeholder="Enter Loan Number " Style={"margin-bottom:20px"}></input> */}
                                        <label Style="padding-bottom:20px">Enter Loan Status for Loan Number : {this.state.loanNumber}</label>
                                        <input type="text" class="form-control" placeholder="Enter Loan Status" Style={"margin-bottom:20px;"} name="loanStatus" onChange={(e) => this.handleChange({ loanStatus: e.target.value })}></input>
                                        <p style={{color:"red"}}>{this.state.updateerror}</p>

                                        {/* <input type="text" name="" class="form-control" placeholder="Enter Loan Status" Style={"margin-bottom:20px"}></input> */}
                                        {/* <button class="btn btn-dark btn-block" Style={"margin-bottom:20px"}>Update</button> */}
                                        <button class="btn btn-dark btn-block" Style={"margin-bottom:20px"} onClick={this.AdminLoanStatus} >Update</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="favorite styled" onClick={this.submit1}
                        type="button">Show Applied Loans
                    </button>
                    <div Style="display:inline-block;padding-left:250px">
                        <AdminLogout></AdminLogout>
                    </div>
                </div>
                <div>
                    <Footer1 />
                </div>
            </>
        )
    }
}

{/* <table border={1} align="center">
                    <tr>
                        <td>
                            <label>Enter Loan Number</label>
                            <input type="text" name="loanNumber" onChange={(e) => this.handleChange({ loanNumber: e.target.value })}></input>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Enter Loan Status</label>
                            <input type="text" name="loanStatus" onChange={(e) => this.handleChange({ loanStatus: e.target.value })}></input>
                        </td>
                    </tr>


                    <tr>
                        <td>

                            <button onClick={this.AdminLoanStatus} >Loan Status</button>

                        </td>
                    </tr>


                </table> */}