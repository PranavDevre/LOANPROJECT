import React, { Component } from 'react'
import axios from 'axios'
import AdminLogout from './AdminLogout';
import Header from '../../Components/Header';
import Footer1 from '../../Components/Footer1';
export default class AdminEdit extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        adminId:'',
        name:'',
        password:'',
        confirmPassword:'',
        emailAddress:''
      }
      this.AdminEdit=this.AdminEdit.bind(this);
      this.handleChange=this.handleChange.bind(this);
    }
    AdminEdit()
    {
         this.setState({
              nameerror:'',passworderror:'',confirmPassworderror:'',emailAddresserror: ''
     })
     if(this.Validate())
     {
        let adminId=this.state.adminId;
        let url="http://localhost:11380/api/Admin/"+adminId;
        axios.put(url,{
            name:this.state.name,
            password:this.state.password,
            confirmPassword:this.state.confirmPassword,
            emailAddress:this.state.emailAddress

        }).then(response=>{
            alert("Data Updated");
            window.location="/AdminLogin";

        }).catch(error=>{
            alert(error);
        });
    }
    }
    handleChange(object)
    {
        this.setState(object);

    }

    submit1()
    {
        window.location="/ShowAllLoans";
    }

    Validate()
    {
       if(!this.state.name.includes(" ") )
        {
            this.setState({nameerror:'Enter Your Full Name'});
        }
       else if(this.state.password.length<8)
        {
            this.setState({passworderror:'Password Length Should Be More Than 8 characters'}); 
        }
        else if(this.state.confirmPassword != this.state.password)
        {
            this.setState({confirmPassworderror:'Password  and confirm password should be same'}); 
        }
        else if(!this.state.emailAddress.includes("@"))
        {
            this.setState({emailAddresserror:'Please enter a valid email ID'}); 
        }
       
        else
        {
            return true;
        }
    }


  render() {
    if(sessionStorage.getItem("adminId") == null)
    {
        window.location='/';
    }
    else{
        this.state.adminId = sessionStorage.getItem('adminId');
    }
    return (



        <>
        <div>
            <Header />
        </div>
        <div class='Update'>
            <div id="login-box" Style="height:fit-content;">
                    <h1 Style="padding-left: 0px;">Admin Details</h1>

                    <label className="labelName" Style="padding-left:100px">Name :</label>
                    <input type="text" Style="margin-left: 20px;" name="name" placeholder='name' onChange={(e) => this.handleChange({ name: e.target.value })}></input>
                    <p style={{color:"red"}}>{this.state.nameerror}</p>
                    <label className="labelName" Style="padding-left:70px">Password :</label>
                    <input type="password" Style="margin-left: 20px;" name="password" placeholder='password' onChange={(e) => this.handleChange({ password: e.target.value })}></input>
                    <p style={{color:"red"}}>{this.state.passworderror}</p>
                    <label className="labelName">Confirm Password :</label>
                    <input type="password" Style="margin-left: 20px;" name="confirmPassword" placeholder='confirm password' onChange={(e) => this.handleChange({ confirmPassword: e.target.value })}></input>
                    <p style={{color:"red"}}>{this.state.confirmPassworderror}</p>
                    <label className="labelName" Style="padding-left:40px">Email Address :</label>
                    <input type="text" Style="margin-left: 20px;" name="emailAddress" placeholder='email address' onChange={(e) => this.handleChange({ emailAddress: e.target.value })}></input>
                    <p style={{color:"red"}}>{this.state.emailAddresserror}</p>
                    
                   <button onClick={this.AdminEdit} class="favorite styled "
                        type="button">
                        Update
                    </button><br></br><br></br> 
                    <button class="favorite styled" onClick={this.submit1}
                        type="button">Show Applied Loans
                    </button>      
            </div> 
        </div>
                    
        <div>
            <Footer1 />
        </div>
    </>
)
}
}



//       <div>AdminEdit

// <table border={1} align="center">
//         <tr>
//             <td>
//                 <label>Admin Id</label>
//                 <input type="text" name="adminId" onChange={(e)=>this.handleChange({adminId:e.target.value})}></input>
//             </td>
//             </tr>
//             <tr>
//             <td>
//                 <label>Admin Name</label>
//                 <input type="text" name="name" onChange={(e)=>this.handleChange({name:e.target.value})}></input>
//             </td>
//             </tr>
//             <tr>
//             <td>
//                 <label>Admin password</label>
//                 <input type="text" name="password" onChange={(e)=>this.handleChange({password:e.target.value})}></input>
//             </td>
//             </tr>

//             <tr>
//             <td>
//                 <label>Admin Confirmpassword</label>
//                 <input type="text" name="confirmPassword" onChange={(e)=>this.handleChange({confirmPassword:e.target.value})}></input>
//             </td>
//             </tr>

//             <tr>
//             <td>
//                 <label>Admin emailAddress</label>
//                 <input type="text" name="emailAddress" onChange={(e)=>this.handleChange({emailAddress:e.target.value})}></input>
//             </td>
//             </tr>


            
//             <tr>
//             <td>
               
//                <button onClick={this.AdminEdit} >Edit</button>
              
//             </td>
//             </tr>
      

//         </table>
//         <AdminLogout></AdminLogout>
//       </div>
//     )
//   }
// }
