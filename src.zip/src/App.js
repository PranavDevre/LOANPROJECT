import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes, Link } from 'react-router-dom';
import Header from './Components/Header';
import Home from './Pages/Home';
import AdminLogin from './Pages/Admin/AdminLogin';
import ShowAllLoans from './Pages/Admin/ShowAllLoans';
import AdminLoanStatus from './Pages/Admin/AdminLoanStatus';
import UserLogin1 from './Pages/Customer/UserLogin1';
import Showloantypes from './Pages/Customer/Showloantypes';
import ApplyLoans from './Pages/Customer/ApplyLoans';
import CheckStatus from './Pages/Customer/CheckStatus';
import CustomerLogout from './Pages/Customer/CustomerLogout';
import AdminRegistration from './Pages/Admin/AdminRegistration';
import AdminRegisterLoan from './Pages/Admin/AdminRegisterLoan';
import UserRegistration from './Pages/Customer/UserRegistration';
import AdminLogout from './Pages/Admin/AdminLogout';
import AdminEdit from './Pages/Admin/AdminEdit';
import AdminDelete from './Pages/Admin/AdminDelete';
import UpdateUser from './Pages/Customer/UpdateUser';
import DeleteUser from './Pages/Customer/DeleteUser';
import Aboutus from './Pages/Aboutus';
import Contactus from './Pages/Contactus';
import ForgotPassword from './Pages/Customer/ForgotPassword';
import AdminForgotPassword from './Pages/Admin/AdminForgotPassword';

function App() {

  return (
    <div className="App" id="outer-container">
       
      <div id="page-wrap">
        <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />}></Route>
          <Route path='/Home' element={<Home />}></Route>
          <Route path='/Aboutus' element={<Aboutus />}></Route>
          <Route path='/Contactus' element={<Contactus />}></Route>

          <Route path='/AdminLogin' element={<AdminLogin />}></Route>
          <Route path='/ShowAllLoans' element={<ShowAllLoans />}></Route>
          <Route path='/AdminLoanStatus' element={<AdminLoanStatus />}></Route>
          <Route path='/AdminRegistration' element={<AdminRegistration />}></Route>
          <Route path='/AdminRegisterLoan' element={<AdminRegisterLoan />}></Route>
          <Route path='/AdminLogout' element={<AdminLogout />}></Route>
          <Route path='/AdminEdit' element={<AdminEdit />}></Route>
          <Route path='/AdminDelete' element={<AdminDelete />}></Route>
          <Route path='/AdminForgotPassword' element={<AdminForgotPassword />}></Route>

          <Route path='/UserLogin1' element={<UserLogin1 />}></Route>
          <Route path='/Showloantypes' element={<Showloantypes />}></Route>
          <Route path='/ApplyLoans' element={<ApplyLoans />}></Route>
          <Route path='/CheckStatus' element={<CheckStatus />}></Route>
          <Route path='/CustomerLogout' element={<CustomerLogout />}></Route>
          <Route path='/UserRegistration' element={<UserRegistration />}></Route>
          <Route path='/UpdateUser' element={<UpdateUser />}></Route>
          <Route path='/DeleteUser' element={<DeleteUser />}></Route>
          <Route path='/ForgotPassword' element={<ForgotPassword />}></Route>


          </Routes>
      </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
